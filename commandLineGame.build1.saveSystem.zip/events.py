from playerClass import Player
import json

classesfile = open('gameStats.json')
allStats = json.load(classesfile)
allClasses = allStats[0]

def initItems(currPlayer:Player):
    myClass = currPlayer._class
    if myClass == 1:
        return "a"
    elif myClass == 2:
        return "Thief"
    elif myClass == 3:
        return "Monk"
    elif myClass == 4:
        return "Farmer"
    elif myClass == 5:
        return "Archer"
    elif myClass == 6:
        return "Nomad"